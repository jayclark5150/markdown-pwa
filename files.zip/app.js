// ── Config ────────────────────────────────────────────────────────────────────
// Replace with your own Google API credentials from console.cloud.google.com
const GOOGLE_CLIENT_ID = 'YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com';
const GOOGLE_API_KEY   = 'YOUR_GOOGLE_API_KEY';
const SCOPES           = 'https://www.googleapis.com/auth/drive.file';
const DISCOVERY_DOC    = 'https://www.googleapis.com/discovery/v1/apis/drive/v3/rest';

// ── State ─────────────────────────────────────────────────────────────────────
let driveConnected  = false;
let driveFileId     = null;   // currently open Drive file ID
let driveFileName   = null;
let localFileHandle = null;   // File System Access API handle (Chrome/Edge)
let currentTitle    = 'New Document';
let isDirty         = false;
let autoSaveTimer   = null;
let tokenClient     = null;
let driveFiles      = [];     // cached Drive file list
let selectedDriveFile = null;

// ── DOM refs ──────────────────────────────────────────────────────────────────
const editor         = document.getElementById('editor');
const previewPane    = document.getElementById('preview-pane');
const tbTitle        = document.getElementById('tb-title');
const titleInput     = document.getElementById('title-input');
const driveStatus    = document.getElementById('drive-status');
const driveStatusTxt = document.getElementById('drive-status-text');
const saveStatus     = document.getElementById('save-status');
const driveFileInfo  = document.getElementById('drive-file-info');
const toast          = document.getElementById('toast');

// ── Marked setup ─────────────────────────────────────────────────────────────
if (window.marked && window.hljs) {
  marked.use({
    renderer: {
      code({ text, lang }) {
        const language = (lang && hljs.getLanguage(lang)) ? lang : 'plaintext';
        const highlighted = hljs.highlight(text, { language }).value;
        return `<pre><code class="hljs language-${language}">${highlighted}</code></pre>`;
      }
    }
  });
}

// ── Render ────────────────────────────────────────────────────────────────────
function renderPreview() {
  if (window.marked && window.DOMPurify) {
    previewPane.innerHTML = DOMPurify.sanitize(marked.parse(editor.value));
  }
}

function updateStats() {
  const text  = editor.value;
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  document.getElementById('word-count').textContent = `Words: ${words}`;
  document.getElementById('char-count').textContent = `Chars: ${text.length}`;
}

function updateCursor() {
  const before = editor.value.slice(0, editor.selectionStart);
  const lines  = before.split('\n');
  document.getElementById('cursor-pos').textContent =
    `Ln ${lines.length}, Col ${lines[lines.length - 1].length + 1}`;
}

editor.addEventListener('input', () => {
  isDirty = true;
  renderPreview();
  updateStats();
  scheduleAutoSave();
});
editor.addEventListener('click',  updateCursor);
editor.addEventListener('keyup',  updateCursor);

// ── Toast ─────────────────────────────────────────────────────────────────────
let toastTimer;
function showToast(msg, duration = 2500) {
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), duration);
}

// ── Title editing ─────────────────────────────────────────────────────────────
tbTitle.addEventListener('click', () => {
  titleInput.value = currentTitle;
  tbTitle.style.display = 'none';
  titleInput.style.display = 'block';
  titleInput.focus();
  titleInput.select();
});

titleInput.addEventListener('blur', commitTitle);
titleInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter')  commitTitle();
  if (e.key === 'Escape') { titleInput.style.display = 'none'; tbTitle.style.display = ''; }
});

function commitTitle() {
  const v = titleInput.value.trim();
  if (v) {
    currentTitle = v.endsWith('.md') || v.endsWith('.txt') ? v : v + '.md';
    tbTitle.textContent = currentTitle;
    if (driveFileId) driveFileName = currentTitle;
  }
  titleInput.style.display = 'none';
  tbTitle.style.display = '';
}

function setTitle(name) {
  currentTitle = name;
  tbTitle.textContent = name;
}

// ── Drive status display ──────────────────────────────────────────────────────
function setDriveStatus(state, text) {
  driveStatus.className = 'drive-status ' + state;
  driveStatusTxt.textContent = text;
}

// ── Auto-save ─────────────────────────────────────────────────────────────────
function scheduleAutoSave() {
  clearTimeout(autoSaveTimer);
  if (!driveConnected && !localFileHandle) return;
  saveStatus.textContent = 'Unsaved…';
  autoSaveTimer = setTimeout(async () => {
    await performSave(true);
  }, 2000);
}

async function performSave(silent = false) {
  if (!isDirty) return;
  const content = editor.value;

  // Priority: Drive > local file handle > download
  if (driveConnected && driveFileId) {
    await saveToDrive(content, silent);
  } else if (driveConnected) {
    await saveNewToDrive(content, currentTitle, silent);
  } else if (localFileHandle) {
    await saveToLocalHandle(content, silent);
  } else {
    downloadFile(content, currentTitle);
  }
}

// ── Local file (File System Access API) ──────────────────────────────────────
document.getElementById('open-local-btn').addEventListener('click', () => {
  if ('showOpenFilePicker' in window) {
    openWithFilePicker();
  } else {
    document.getElementById('file-input').click();
  }
});

async function openWithFilePicker() {
  try {
    const [handle] = await window.showOpenFilePicker({
      types: [{ description: 'Markdown', accept: { 'text/markdown': ['.md', '.txt', '.markdown'] } }]
    });
    localFileHandle = handle;
    driveFileId = null;
    const file    = await handle.getFile();
    const content = await file.text();
    editor.value  = content;
    setTitle(file.name);
    isDirty = false;
    saveStatus.textContent = 'Opened';
    renderPreview(); updateStats(); updateCursor();
    driveFileInfo.textContent = '📄 Local file';
  } catch (e) {
    if (e.name !== 'AbortError') showToast('Could not open file: ' + e.message);
  }
}

// Fallback for browsers without File System Access API (Safari, Firefox)
document.getElementById('file-input').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  localFileHandle = null;
  driveFileId = null;
  const content = await file.text();
  editor.value  = content;
  setTitle(file.name);
  isDirty = false;
  saveStatus.textContent = 'Opened';
  renderPreview(); updateStats(); updateCursor();
  driveFileInfo.textContent = '📄 Local file';
  e.target.value = '';
});

async function saveToLocalHandle(content, silent = false) {
  try {
    const writable = await localFileHandle.createWritable();
    await writable.write(content);
    await writable.close();
    isDirty = false;
    saveStatus.textContent = silent ? `Saved ${new Date().toLocaleTimeString()}` : 'Saved';
    if (!silent) showToast('✓ Saved');
  } catch (e) {
    saveStatus.textContent = 'Save failed';
    showToast('Save failed: ' + e.message);
  }
}

// ── Save button ───────────────────────────────────────────────────────────────
document.getElementById('save-local-btn').addEventListener('click', async () => {
  if (driveConnected) {
    await performSave(false);
  } else if (localFileHandle) {
    await saveToLocalHandle(editor.value, false);
  } else if ('showSaveFilePicker' in window) {
    try {
      localFileHandle = await window.showSaveFilePicker({
        suggestedName: currentTitle,
        types: [{ description: 'Markdown', accept: { 'text/markdown': ['.md'] } }]
      });
      await saveToLocalHandle(editor.value, false);
    } catch (e) {
      if (e.name !== 'AbortError') downloadFile(editor.value, currentTitle);
    }
  } else {
    downloadFile(editor.value, currentTitle);
  }
});

function downloadFile(content, filename) {
  const a   = document.createElement('a');
  a.href    = URL.createObjectURL(new Blob([content], { type: 'text/markdown' }));
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
  isDirty = false;
  saveStatus.textContent = 'Downloaded';
  showToast('✓ Downloaded ' + filename);
}

// ── New file ──────────────────────────────────────────────────────────────────
document.getElementById('new-btn').addEventListener('click', () => {
  if (isDirty) {
    if (!confirm('You have unsaved changes. Create new document anyway?')) return;
  }
  openNewModal();
});

function openNewModal() {
  document.getElementById('new-filename').value = '';
  document.getElementById('new-modal').classList.add('open');
  setTimeout(() => document.getElementById('new-filename').focus(), 50);
}

document.getElementById('new-modal-cancel').addEventListener('click', () => {
  document.getElementById('new-modal').classList.remove('open');
});

document.getElementById('new-modal-ok').addEventListener('click', createNewDoc);
document.getElementById('new-filename').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') createNewDoc();
  if (e.key === 'Escape') document.getElementById('new-modal').classList.remove('open');
});

function createNewDoc() {
  let name = document.getElementById('new-filename').value.trim() || 'untitled.md';
  if (!name.includes('.')) name += '.md';
  document.getElementById('new-modal').classList.remove('open');
  editor.value = '';
  setTitle(name);
  localFileHandle = null;
  driveFileId     = null;
  driveFileName   = null;
  isDirty         = false;
  saveStatus.textContent = '';
  driveFileInfo.textContent = driveConnected ? '☁ Drive (new)' : '';
  renderPreview(); updateStats(); updateCursor();
}

// ── Google Drive Integration ──────────────────────────────────────────────────
async function initGoogleApi() {
  return new Promise((resolve) => {
    gapi.load('client', async () => {
      await gapi.client.init({
        apiKey: GOOGLE_API_KEY,
        discoveryDocs: [DISCOVERY_DOC],
      });
      resolve();
    });
  });
}

function initTokenClient() {
  tokenClient = google.accounts.oauth2.initTokenClient({
    client_id: GOOGLE_CLIENT_ID,
    scope: SCOPES,
    callback: async (response) => {
      if (response.error) {
        setDriveStatus('error', 'Auth failed');
        showToast('Google sign-in failed: ' + response.error);
        return;
      }
      onDriveConnected();
    },
  });
}

function onDriveConnected() {
  driveConnected = true;
  setDriveStatus('connected', 'Drive connected');
  document.getElementById('drive-signin-btn').style.display  = 'none';
  document.getElementById('drive-open-btn').style.display    = '';
  document.getElementById('drive-save-btn').style.display    = '';
  document.getElementById('drive-signout-btn').style.display = '';
  if (!driveFileId) driveFileInfo.textContent = '☁ Drive (new)';
  showToast('✓ Connected to Google Drive');
  fetchDriveFiles();
}

document.getElementById('drive-signin-btn').addEventListener('click', async () => {
  if (!GOOGLE_CLIENT_ID || GOOGLE_CLIENT_ID.includes('YOUR_')) {
    showToast('⚠ Add your Google Client ID in app.js first', 4000);
    return;
  }
  await initGoogleApi();
  initTokenClient();
  tokenClient.requestAccessToken({ prompt: 'consent' });
});

document.getElementById('drive-signout-btn').addEventListener('click', () => {
  const token = gapi.client.getToken();
  if (token) google.accounts.oauth2.revoke(token.access_token);
  gapi.client.setToken('');
  driveConnected  = false;
  driveFileId     = null;
  driveFileName   = null;
  setDriveStatus('', 'Not connected');
  document.getElementById('drive-signin-btn').style.display  = '';
  document.getElementById('drive-open-btn').style.display    = 'none';
  document.getElementById('drive-save-btn').style.display    = 'none';
  document.getElementById('drive-signout-btn').style.display = 'none';
  driveFileInfo.textContent = '';
  showToast('Signed out of Google Drive');
});

// ── Fetch Drive files ─────────────────────────────────────────────────────────
async function fetchDriveFiles(query = '') {
  try {
    setDriveStatus('saving', 'Loading files…');
    let q = "mimeType='text/plain' or mimeType='text/markdown' or fileExtension='md'";
    if (query) q = `name contains '${query}' and (${q})`;
    q += " and trashed=false";

    const res = await gapi.client.drive.files.list({
      q,
      fields: 'files(id,name,modifiedTime,size)',
      orderBy: 'modifiedTime desc',
      pageSize: 50,
    });
    driveFiles = res.result.files || [];
    setDriveStatus('connected', 'Drive connected');
    return driveFiles;
  } catch (e) {
    setDriveStatus('error', 'Load failed');
    showToast('Could not load Drive files: ' + e.message);
    return [];
  }
}

// ── Drive file picker ─────────────────────────────────────────────────────────
document.getElementById('drive-open-btn').addEventListener('click', async () => {
  await fetchDriveFiles();
  renderDriveFileList(driveFiles);
  document.getElementById('drive-modal').classList.add('open');
  document.getElementById('drive-search').value = '';
  selectedDriveFile = null;
});

document.getElementById('drive-modal-cancel').addEventListener('click', () => {
  document.getElementById('drive-modal').classList.remove('open');
});

document.getElementById('drive-search').addEventListener('input', async (e) => {
  const q = e.target.value.trim();
  const files = q ? await fetchDriveFiles(q) : driveFiles;
  renderDriveFileList(files);
});

function renderDriveFileList(files) {
  const list = document.getElementById('drive-file-list');
  if (!files.length) {
    list.innerHTML = '<div class="file-item" style="color:var(--text2);cursor:default">No markdown files found in Drive</div>';
    return;
  }
  list.innerHTML = files.map(f => `
    <div class="file-item" data-id="${f.id}" data-name="${f.name}">
      <span class="file-icon">📄</span>
      <span class="file-name">${f.name}</span>
      <span class="file-date">${new Date(f.modifiedTime).toLocaleDateString()}</span>
    </div>
  `).join('');

  list.querySelectorAll('.file-item').forEach(el => {
    el.addEventListener('click', () => {
      list.querySelectorAll('.file-item').forEach(i => i.classList.remove('selected'));
      el.classList.add('selected');
      selectedDriveFile = { id: el.dataset.id, name: el.dataset.name };
    });
    el.addEventListener('dblclick', () => {
      selectedDriveFile = { id: el.dataset.id, name: el.dataset.name };
      openSelectedDriveFile();
    });
  });
}

document.getElementById('drive-modal-open').addEventListener('click', openSelectedDriveFile);

async function openSelectedDriveFile() {
  if (!selectedDriveFile) { showToast('Select a file first'); return; }
  document.getElementById('drive-modal').classList.remove('open');
  await loadDriveFile(selectedDriveFile.id, selectedDriveFile.name);
}

async function loadDriveFile(fileId, fileName) {
  try {
    setDriveStatus('saving', 'Loading…');
    const res = await gapi.client.drive.files.get({
      fileId,
      alt: 'media',
    });
    editor.value = res.body;
    driveFileId   = fileId;
    driveFileName = fileName;
    localFileHandle = null;
    setTitle(fileName);
    isDirty = false;
    saveStatus.textContent = 'Opened from Drive';
    driveFileInfo.textContent = '☁ Google Drive';
    setDriveStatus('connected', 'Drive connected');
    renderPreview(); updateStats(); updateCursor();
    showToast('✓ Opened ' + fileName);
  } catch (e) {
    setDriveStatus('error', 'Load failed');
    showToast('Could not open file: ' + e.message);
  }
}

// ── Save to Drive ─────────────────────────────────────────────────────────────
document.getElementById('drive-save-btn').addEventListener('click', () => performSave(false));

async function saveToDrive(content, silent = false) {
  try {
    setDriveStatus('saving', 'Saving…');
    const boundary = '-------314159265358979323846';
    const metadata = JSON.stringify({ name: driveFileName || currentTitle, mimeType: 'text/markdown' });
    const body = `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${metadata}\r\n--${boundary}\r\nContent-Type: text/markdown\r\n\r\n${content}\r\n--${boundary}--`;

    const res = await gapi.client.request({
      path: `/upload/drive/v3/files/${driveFileId}`,
      method: 'PATCH',
      params: { uploadType: 'multipart' },
      headers: { 'Content-Type': `multipart/related; boundary="${boundary}"` },
      body,
    });

    isDirty = false;
    saveStatus.textContent = silent ? `Saved ${new Date().toLocaleTimeString()}` : 'Saved to Drive';
    setDriveStatus('connected', 'Drive connected');
    if (!silent) showToast('✓ Saved to Google Drive');
  } catch (e) {
    setDriveStatus('error', 'Save failed');
    showToast('Drive save failed: ' + e.message);
  }
}

async function saveNewToDrive(content, filename, silent = false) {
  try {
    setDriveStatus('saving', 'Saving…');
    const boundary = '-------314159265358979323846';
    const metadata = JSON.stringify({ name: filename, mimeType: 'text/markdown' });
    const body = `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${metadata}\r\n--${boundary}\r\nContent-Type: text/markdown\r\n\r\n${content}\r\n--${boundary}--`;

    const res = await gapi.client.request({
      path: '/upload/drive/v3/files',
      method: 'POST',
      params: { uploadType: 'multipart' },
      headers: { 'Content-Type': `multipart/related; boundary="${boundary}"` },
      body,
    });

    driveFileId   = res.result.id;
    driveFileName = filename;
    isDirty = false;
    saveStatus.textContent = 'Saved to Drive';
    driveFileInfo.textContent = '☁ Google Drive';
    setDriveStatus('connected', 'Drive connected');
    if (!silent) showToast('✓ Saved to Google Drive');
    fetchDriveFiles(); // refresh list
  } catch (e) {
    setDriveStatus('error', 'Save failed');
    showToast('Drive save failed: ' + e.message);
  }
}

// ── Keyboard shortcuts ────────────────────────────────────────────────────────
document.addEventListener('keydown', (e) => {
  const mod = e.ctrlKey || e.metaKey;
  if (mod && e.key === 's') { e.preventDefault(); performSave(false); }
  if (mod && e.key === 'n') { e.preventDefault(); if (!isDirty || confirm('Discard changes?')) openNewModal(); }
  if (mod && e.key === 'o') { e.preventDefault(); document.getElementById('open-local-btn').click(); }
});

// ── PWA install prompt ────────────────────────────────────────────────────────
let deferredPrompt;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  document.getElementById('install-banner').classList.add('show');
});

document.getElementById('install-btn').addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice;
  deferredPrompt = null;
  document.getElementById('install-banner').classList.remove('show');
});

document.getElementById('install-close').addEventListener('click', () => {
  document.getElementById('install-banner').classList.remove('show');
});

// ── Service worker registration ───────────────────────────────────────────────
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('sw.js').catch(console.error);
}

// ── Boot ──────────────────────────────────────────────────────────────────────
renderPreview();
updateStats();
updateCursor();
